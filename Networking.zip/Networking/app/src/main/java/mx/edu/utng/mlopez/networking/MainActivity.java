package mx.edu.utng.mlopez.networking;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import android.util.Log;

import android.widget.ImageView;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private ImageView img;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        img = (ImageView)findViewById(R.id.img);
        new DownloadImageTask().execute(
                "http://desingheaven.files.wordpress.com/2010/04/eiffel_tower_paris_france.jpg",
                "http://www.mayoff.com/5-01cablecarDCP01934.jpg");
    }

    /*
            "http://www.hartiesinfo.net/greybox/Cable_Car_Hartbeespoort.jpg",
            "http://mcmanuslab.ucsf.edu/sites/default/files/imagepicker/m/mmcmanus/CaliforniaSanFranciscoPaintedLadiesHz.jpg",
            "http://www.fantom-xp.com/wallpapers/63/San_Francisco_-_Sunset.jpg",
            "http://travel.roro44.com/europe/france/Paris_France.jpg",
            "http://wwp.greenwichmeantime.com/time-zone/usa/necada/las-vegas/hotel/the-strip/paris-las-vegas/parislas-vegas-hotel.jpg",
            "http://desingheaven.files.wordpress.com/2010/04/eiffel_tower_paris_france.jpg");*/

    private InputStream OpenHttpConnection(String urlString) throws IOException{
        InputStream in = null;
        int response = -1;

        URL url = new URL(urlString);
        URLConnection conn = url.openConnection();

        if(!(conn instanceof HttpURLConnection)){
            throw new IOException("No es una conexión HTTP!");
        }

        try {
            HttpURLConnection httpconn = (HttpURLConnection) conn;
            httpconn.setAllowUserInteraction(false);
            httpconn.setInstanceFollowRedirects(true);
            httpconn.setRequestMethod("GET");
            httpconn.connect();
            response = httpconn.getResponseCode();
            if(response == HttpURLConnection.HTTP_OK){
                in = httpconn.getInputStream();
            }
        }catch(Exception ex){
            Log.d("Networking", ex.getLocalizedMessage());
            throw new IOException("Error connecting.");
        }
        return in;
    }

    private Bitmap DownloadImage(String url){
        Bitmap bitmap = null;
        InputStream in = null;

        try {
            in = OpenHttpConnection(url);
            bitmap = BitmapFactory.decodeStream(in);
            in.close();
        }catch(IOException e1){
            Log.d("NetworkingActivity", e1.getLocalizedMessage());
        }
        return bitmap;
    }

    private class DownloadImageTask extends AsyncTask<String, Bitmap, Long>{
        protected Long doInBackground (String...urls){
            long imageCount = 0;
            for (int i = 0; i < urls.length; i++){
                Bitmap imageDownloaded = DownloadImage(urls[i]);
                if (imageDownloaded != null){
                    imageCount++;
                    try{
                        Thread.sleep(3000);
                    }catch (InterruptedException e){
                        e.printStackTrace();
                    }
                    publishProgress(imageDownloaded);
                }
            }
            return imageCount;
        }
        protected void onProgressUpdate(Bitmap... bitmap){
            img.setImageBitmap(bitmap[0]);
        }
        protected void onPostExecute(Long imageDownloaded){
            Toast.makeText(getBaseContext(),"Total"+imageDownloaded+"Images Downloaded", Toast.LENGTH_LONG).show();
        }
    }
}/* End */